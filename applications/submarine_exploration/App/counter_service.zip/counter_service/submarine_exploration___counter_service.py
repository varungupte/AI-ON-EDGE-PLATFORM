from flask import Flask,render_template
import time
import json
import os
import pymongo
import threading
import subprocess
import requests

app = Flask(__name__)

import xmltodict

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="submarine_exploration"
service_id="counter_service"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)


def find_self_ip():
    wifi_interface = os.popen('ifconfig | grep -o  ^w[^:]*').read().strip('\n')
    ip = os.popen("ifconfig "+wifi_interface+" | grep inet | awk '{print $2}'| cut -f2 -d:").read().strip('\n')
    return ip

self_ip=find_self_ip()

for x in mydoc:
    node_ips=x['node_ips']
    output_address = x['output_stream']

x = node_ips.split(' ')

for m in x:
    if self_ip in m:
        port_no=(m.split(':')[1])

# print('Assigning following port to flask: ',port_no)

count = 0
count = int((open(os.path.dirname(os.path.realpath(__file__))+"/demofile.txt", "r")).read())
#print(count)

try:
    requests.get(url='http://'+output_address+'/set', params={'count': count})
except:
    print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")

@app.route("/")
def get_index():
    global count
    #count = count + 1
    # return "Count is : " + str(count)
    return str(count)

@app.route("/inc")
def inc():
    global count, output_address
    print('inc request')
    count = count + 1
    try:
        resp = requests.get(url='http://'+output_address+'/set', params={'count': count})
        print('inc success')
        print(resp.text)
    except:
        print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")
    return str(count)


if __name__ == "__main__":
    app.run(host=self_ip, port=port_no)
