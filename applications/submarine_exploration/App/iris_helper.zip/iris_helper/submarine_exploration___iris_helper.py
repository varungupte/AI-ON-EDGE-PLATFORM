import requests
import sys
import time
import os
import json
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import xmltodict
import pickle
import datetime
import numpy as np

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)
database = myclient['metadata']
service_metadata = database['service_metadata']

query = {'application_id': 'submarine_exploration', 'service_id': 'iris_helper'}
for x in service_metadata.find(query):
    output_address = 'http://'+x['output_stream']+'/inc'

RPC = RpcHandler()
REQ = ReqHandler()

def serve():
    global RPC, REQ, output_address
    iris_data = RPC.call(call_type='get', sensor_id='iris001', parameters=[1])
    iris_data = pickle.loads(iris_data)[0]
    iris_data = [float(iris_data[i]) for i in range(len(iris_data))]

    print('Iris Data:',iris_data)

    server_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                          application_id = 'submarine_exploration', service_id = 'iris_model',
                          parameters = [10]).decode()

    server_add = server_add.replace("'",'"')
    server_add = json.loads(server_add)
    server_add = server_add['rest_url'].split('/')[0]
    server_add = 'http://'+server_add+'/v1/models/iris_model:predict'

    print('model address:',server_add)

    headers = {"content-type": "application/json"}
    data = json.dumps({"signature_name": "serving_default", "instances": [iris_data]})

    try:
        json_response = requests.post(url=server_add, data=data, headers=headers)
    except:
        print('Iris Model is not up')

    prediction = json.loads(json_response.text)['predictions']

    print('predictions',prediction)
    # setosa = prediction[0]
    # versicolor = prediction[1]
    # virginica = prediction[2]

    predication = np.argmax(prediction[0])

    try:
        requests.post(url=output_address, params={'prediction':predication})
    except:
        print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")


from apscheduler.schedulers.blocking import BlockingScheduler

job_defaults = {
    'coalesce': False,
    'max_instances': 3
}
sched = BlockingScheduler(job_defaults=job_defaults)
sched.add_job(serve, 'interval', seconds=0.5, next_run_time=datetime.datetime.now()+datetime.timedelta(seconds=0.05))
sched.start()
