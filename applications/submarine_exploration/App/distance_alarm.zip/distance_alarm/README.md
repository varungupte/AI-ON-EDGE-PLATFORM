This service accepts the output of Distance Sensor and checks its range.
