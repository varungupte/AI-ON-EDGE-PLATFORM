import smtplib, ssl
from RPCHandler import RpcHandler
import pickle
import time
import json
import os
import pymongo
import threading
import subprocess
import smtplib
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart


def send_mail(distance):

    try:
        Port = 587  # For SSL
        Server = "smtp.gmail.com"
        sender_email = "iasproject.2019@gmail.com"  # Enter your address
        receiver_emails = ['ankush.ngpl23@gmail.com', 'devesh.tewari48@gmail.com', 'aman.sharma@students.iiit.ac.in', 'anurag.chaturvedi@students.iiit.ac.in']  # Enter receiver address
        password = "#iasproject.2019#"
        msg = MIMEMultipart()
        msg['Subject'] = 'subject'

        for receiver_email in receiver_emails:
            msg['From'] = sender_email
            msg['To'] = receiver_email

            text = MIMEText("Caution!! The Submarine is about to hit the ground. Distance= "+str(distance))
            msg.attach(text)

            s = smtplib.SMTP(Server, Port)
            s.ehlo()
            s.starttls()
            s.ehlo()
            s.login(sender_email, password)
            s.sendmail(sender_email, receiver_email, msg.as_string())
            s.quit()
    except:
        pass

c=0

def f():
	while(1):
		global c, rpc_call

		res= rpc_call.call(call_type= 'get',sensor_id='distance001',parameters=[1])
		# print("res=",res)
		res=pickle.loads(res)
		# print(type(res))
		distance= res[0]
		# print("distance global = ",distance)
		# print("c= ",c)

		if(distance>=200):
			c=0

		if(distance<200 and c==0):
			print("value <200")
			print("distance= ",distance)
			send_mail(distance)
			c=1

		time.sleep(1)



rpc_call = RpcHandler()
# global c
f()
# c=0
# send_mail(50)
