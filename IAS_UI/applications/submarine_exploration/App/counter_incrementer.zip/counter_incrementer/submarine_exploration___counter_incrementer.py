import requests
from REQHandler import ReqHandler
import json

REQ = ReqHandler()

counter_service_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
					application_id = 'submarine_exploration', service_id = 'counter_service',
					parameters = [10]).decode()
print('String format---------->>>>>>>>>>>>',counter_service_add)

counter_service_add = counter_service_add.replace("'",'"')
counter_service_add = json.loads(counter_service_add)
counter_service_add = counter_service_add['rest_url'].split('/')[0]

print('From Handler----------->>>>>>>>>>>',counter_service_add)
resp = requests.get(url='http://'+counter_service_add+'/inc')
print('Response------------->>>>>>>>>>>>>>',resp.text)
