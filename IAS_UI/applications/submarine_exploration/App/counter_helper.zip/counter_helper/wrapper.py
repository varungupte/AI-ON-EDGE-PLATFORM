import urllib.request as urllib2
import requests
import xmltodict
import pymongo
import pickle
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import os
import json

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)
database = myclient['metadata']
service_metadata = database['service_metadata']


def get_service_type(app_id, service_id):
    global service_metadata
    query = {'service_id': service_id, 'application_id': app_id}
    for x in service_metadata.find(query):
        return x['nature_of_service']


def get_model_input_metadata(app_id, service_id):
    global service_metadata
    query = {'service_id': service_id, 'application_id': app_id}
    for x in service_metadata.find(query):
        return x['model_name'], x['input_tensor_name']


####Delete all flags before declare#####
def del_all_flags(FLAGS):
    flags_dict = FLAGS._flags()
    keys_list = [keys for keys in flags_dict]
    for keys in keys_list:
        FLAGS.__delattr__(keys)


class Wrapper:

    def __init__():
        del_all_flags(tf.flags.FLAGS)
        self.sensorRPC = RpcHandler()
        self.serviceREQ = ReqHandler()


    def sensor_to_service(sensor_id, app_id, service_id):
        sensor_data = RPC.call(call_type='get', sensor_id=sensor_id, parameters=[1])
        sensor_data = pickle.load(sensor_data)[0]

        return self.redirect_to_service(app_id, service_id, sensor_data)


    def redirect_to_browser(self, browser_addr, prev_output):

        try:
            output = str(output)
        except:
            print('Error. Output is not a string!')
            return

        url = 'http://'+browser_addr+'?output='+prev_output

        return requests.get(url=url)


    def redirect_to_service(self, app_id, service_id, prev_output):

        service_addr = self.serviceREQ.call(call_type = 'rest_call',
                              call_to = 'server/edge',
                              application_id = app_id, service_id = service_id,
                              parameters = [10])

        server_addr = server_addr.replace("'",'"')
        server_addr = json.loads(server_addr)
        server_addr = server_addr['rest_url'].split('/')[0]

        service_type = get_service_type(app_id, service_id)

        if service_type == 'flask':
            try:
                prev_output = str(prev_output)
            except:
                print('Error. Output is not a string!')
                return

            url = 'http://'+service_addr+'?output='+prev_output

            return requests.get(url=url)


        elif service_type == 'tensorflow_serving':
            server_addr = 'http://'+server_addr+'/v1/models/'+service_id+':predict'

            headers = {"content-type": "application/json"}
            data = json.dumps({"signature_name": "serving_default", "instances": [prev_output]})
            json_response = requests.post('http://'+service_addr+'/v1/models/'+service_id+':predict', data=data, headers=headers)
            prediction = json.loads(json_response.text)['predictions']

            return prediction
