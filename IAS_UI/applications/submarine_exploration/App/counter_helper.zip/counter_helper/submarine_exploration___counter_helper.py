import requests
import sys
import time
import os
import json
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import xmltodict
import pickle
from wrapper import Wrapper
import datetime


import xmltodict

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="submarine_exploration"
service_id="sonar_model"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)

for x in mydoc:
    node_ips=x['node_ips']
    sonar_output_address = 'http://'+x['output_stream']+'/inc'


RPC = RpcHandler()
REQ = ReqHandler()

def serve():
    global RPC, REQ

    sonar_data = RPC.call(call_type='get', sensor_id='sonar001', parameters=[1])
    sonar_data = pickle.loads(sonar_data)[0]
    sonar_data = [float(sonar_data[i]) for i in range(len(sonar_data))]
    print('SENSOR DATA:',sonar_data)

    server_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                          application_id = 'submarine_exploration', service_id = 'sonar_model',
                          parameters = [10]).decode()

    server_add = server_add.replace("'",'"')
    server_add = json.loads(server_add)
    server_add = server_add['rest_url'].split('/')[0]
    server_add = 'http://'+server_add+'/v1/models/sonar_model:predict'
    print('SERVER ADDRESS:',server_add)

    headers = {"content-type": "application/json"}
    data = json.dumps({"signature_name": "serving_default", "instances": [sonar_data]})

    try:
        json_response = requests.post(url=server_add, data=data, headers=headers)
    except:
        print('Sonar Model is not up')

    # json_response = Wrapper.sensor_to_service(2, 'submarine_exploration', 'sonar_model')

    prediction = json.loads(json_response.text)['predictions']
    print('PREDICTIONS:',prediction)

    mine = prediction[0][0]
    rock = prediction[0][1]

    if mine > rock:
        counter_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                              application_id = 'submarine_exploration', service_id = 'counter_service',
                              parameters = [10]).decode()

        counter_add = counter_add.replace("'",'"')
        counter_add = json.loads(counter_add)
        counter_add = counter_add['rest_url'].split('/')[0]
        counter_add = 'http://'+counter_add+'/inc'

        try:
            requests.get(url=counter_add, params=None)
        except:
            print("\033[1;31mCounter service "+counter_add+" is not up!\033[0m")

        try:
            requests.post(url=sonar_output_address, params={'prediction':'1'})
        except:
            print("\033[1;31mSonar Output Address "+sonar_output_address+" is not up!\033[0m")

    else:
        try:
            requests.post(url=sonar_output_address, params={'prediction':'0'})
        except:
            print("\033[1;31mSonar Output Address "+sonar_output_address+" is not up!\033[0m")


from apscheduler.schedulers.blocking import BlockingScheduler

job_defaults = {
    'coalesce': False,
    'max_instances': 2
}
sched = BlockingScheduler(job_defaults=job_defaults)
sched.add_job(serve, 'interval', seconds=10, next_run_time=datetime.datetime.now()+datetime.timedelta(seconds=0.05))
sched.start()
