import smtplib, ssl
import pickle
import time
from flask import Flask,render_template, request
import time
import json
import os
import pymongo
import threading
import subprocess
import smtplib
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
import numpy as np
import cv2


def send_mail():

    Port = 587  # For SSL
    Server = "smtp.gmail.com"
    sender_email = "iasproject.2019@gmail.com"  # Enter your address
    receiver_emails = ['ankush.ngpl23@gmail.com', 'devesh.tewari48@gmail.com', 'aman.sharma@students.iiit.ac.in', 'anurag.chaturvedi@students.iiit.ac.in']  # Enter receiver address
    password = "#iasproject.2019#"

    img_data = open("test.jpeg", 'rb').read()
    msg = MIMEMultipart()
    msg['Subject'] = 'subject'

    for receiver_email in receiver_emails:
        msg['From'] = sender_email
        msg['To'] = receiver_email

        text = MIMEText("Intruder detected. Please find attached image and take neccessary actions.")
        msg.attach(text)
        image = MIMEImage(img_data, name=os.path.basename("test.jpeg"))
        msg.attach(image)

        s = smtplib.SMTP(Server, Port)
        s.ehlo()
        s.starttls()
        s.ehlo()
        s.login(sender_email, password)
        s.sendmail(sender_email, receiver_email, msg.as_string())
        s.quit()



app = Flask(__name__)

import xmltodict

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="the_third_eye"
service_id="emergency_notification"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)


def find_self_ip():
    wifi_interface = os.popen('ifconfig | grep -o  ^w[^:]*').read().strip('\n')
    ip = os.popen("ifconfig "+wifi_interface+" | grep inet | awk '{print $2}'| cut -f2 -d:").read().strip('\n')
    return ip

self_ip=find_self_ip()

for x in mydoc:
    node_ips=x['node_ips']

x = node_ips.split(' ')

for m in x:
    if self_ip in m:
        port_no=(m.split(':')[1])



@app.route("/", methods=['POST'])
def emergency():
    global send_mail

    r = request
    # convert string of image data to uint8
    nparr = np.fromstring(r.data, np.uint8)
    # decode image
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    cv2.imwrite('test.jpeg', img)

    send_mail()
    return "Success"


if __name__ == "__main__":
    app.run(host=self_ip, port=port_no)
