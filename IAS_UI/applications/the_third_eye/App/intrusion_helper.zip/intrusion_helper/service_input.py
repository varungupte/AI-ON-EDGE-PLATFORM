#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import csv
from RPCHandler import RpcHandler
import random
import pickle

CURSOR = 0
INPUTS = []


def addr_parse(addr):
  i = addr.find(':')
  host = '' if i<0 else addr[0:i]
  port = int(addr if i<0 else addr[i+1:])
  return (host, port)


class RequestHandler(BaseHTTPRequestHandler):
  def body(self):
    size = int(self.headers.get('Content-Length'))
    return self.rfile.read(size)

  def body_json(self):
    return json.loads(self.body())

  def send(self, code, body=None, headers=None):
    self.send_response(code)
    for k, v in headers.items():
      self.send_header(k, v)
    self.end_headers()
    if body is not None:
      self.wfile.write(body)

  def send_json(self, code, body):
    heads = {'Content-Type': 'application/json'}
    self.send(code, bytes(json.dumps(body), 'utf8'), heads)

  def do_GET(self):
    global CURSOR, INPUTS
    example = INPUTS[CURSOR]
    CURSOR = (CURSOR+1) % len(INPUTS)
    request = {'examples': [example]}
    print('sending request', request)
    return self.send_json(200, request)


def free_ports(num_ports):
    counter = num_ports
    ports = set()
    while counter > 0:
        rport = random.randint(2000,63000)
        if (rport not in ports):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.bind(("127.0.0.1", rport))
                ports.add(str(rport))
                counter-=1
            except socket.error as e:
                continue
            s.close()
    return ' '.join(list(ports))


free_port_ = free_ports(1)
address = ':'+str(free_port_)


def get_service_port():
    global free_port_
    return free_port_

def start_service():



    # print('reading dataset %s ...' % o.dataset)
    #with open(o.dataset, 'r') as f:
    #  for row in csv.reader(f):
    #    if len(row)==0: continue

    addr = addr_parse(address)
    print('starting input service on ', addr)
    httpd = HTTPServer(addr, RequestHandler)
    httpd.serve_forever()


while True:
    global INPUTS

    # RPC = RpcHandler()
    # sonar_data = RPC.call(call_type='get', sensor_id=2, parameters=[1])
    # sonar_data = pickle.loads(sonar_data)[0]
    sonar_data = [0.5] * 60

    a = ""

    i=1
    input_dict={}
    while i<=60:
      a = "V"+str(i)
      input_dict[a] = float(sonar_data[i-1])
      i+=1

    INPUTS = [input_dict]

    time.sleep(10)
