import requests
import sys
import time
import os
import json
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import xmltodict
import pickle
from wrapper import Wrapper
import datetime
import time

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)
database = myclient['metadata']
service_metadata = database['service_metadata']

query = {'application_id': 'the_third_eye', 'service_id': 'intrusion_helper'}
for x in service_metadata.find(query):
    output_address = x['output_stream']
output_address = 'http://'+output_address+'/inc'


RPC = RpcHandler()
REQ = ReqHandler()

def serve():
    global RPC, REQ, output_address

    intrusion_data = RPC.call(call_type='get', sensor_id='network001', parameters=[1])
    intrusion_data = pickle.loads(intrusion_data)[0]
    intrusion_data = [float(intrusion_data[i]) for i in range(len(intrusion_data))]
    print('SENSOR DATA:',intrusion_data)

    server_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                          application_id = 'the_third_eye', service_id = 'intrusion_model',
                          parameters = [10]).decode()

    server_add = server_add.replace("'",'"')
    server_add = json.loads(server_add)
    server_add = server_add['rest_url'].split('/')[0]
    server_add = 'http://'+server_add+'/v1/models/intrusion_model:predict'
    print('SERVER ADDRESS:',server_add)

    headers = {"content-type": "application/json"}
    data = json.dumps({"signature_name": "serving_default", "instances": [intrusion_data]})

    try:
        json_response = requests.post(url=server_add, data=data, headers=headers)
    except:
        print('intrusion Model is not up')

    # json_response = Wrapper.sensor_to_service(2, 'submarine_exploration', 'intrusion_model')

    prediction = json.loads(json_response.text)['predictions']
    print('PREDICTIONS:',prediction)

    normal = prediction[0][0]
    intruder = prediction[0][1]

    if intruder > normal:
        try:
            requests.post(url=output_address, params={'prediction':'1'})
        except:
            print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")

    else:
        try:
            requests.post(url=output_address, params={'prediction':'0'})
        except:
            print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")


while True:
    serve()
    time.sleep(5)
