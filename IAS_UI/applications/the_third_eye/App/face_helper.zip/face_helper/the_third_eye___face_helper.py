import numpy as np
import cv2
import tensorflow as tf
import pymongo
import urllib.request as urllib2
import xmltodict
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import json
import pickle
import requests
import os

REQ = ReqHandler()
RPC = RpcHandler()
file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)
database = myclient["metadata"]
service_metadata = database["service_metadata"]

query = {'application_id': 'the_third_eye', 'service_id': 'face_helper'}
for x in service_metadata.find(query):
    output_address = x['output_stream']
output_address = 'http://'+output_address+'/show_image'

service_id = 'face_model'
app_id = 'the_third_eye'

####### av:                initialize openCV stuff
faceDetect = cv2.CascadeClassifier(os.path.dirname(os.path.realpath(__file__))+'/haarcascade_frontalface_default.xml')
# cam = cv2.VideoCapture(0)
# ret, img = cam.read()
#######

######## av:                 initialize tensorflow classifier

# Loads label file, strips off carriage return
# label_lines = [line.rstrip() for line
#                    in tf.gfile.GFile("tf_files/retrained_labels.txt")]
#
# # Unpersists graph from file
# with tf.gfile.FastGFile("tf_files/retrained_graph.pb", 'rb') as f:
#     graph_def = tf.GraphDef()
#     graph_def.ParseFromString(f.read())
#     _ = tf.import_graph_def(graph_def, name='')


from grpc.beta import implementations
from tensorflow_serving.apis import predict_pb2
from tensorflow_serving.apis import prediction_service_pb2

####Delete all flags before declare#####
def del_all_flags(FLAGS):
    flags_dict = FLAGS._flags()
    keys_list = [keys for keys in flags_dict]
    for keys in keys_list:
        FLAGS.__delattr__(keys)

del_all_flags(tf.flags.FLAGS)

sent = False
image_path = os.path.dirname(os.path.realpath(__file__))+"/User.jpg"
##load the images into image_path, the classifier has to run 20 times:
def main(_):
    global image_path, service_id, app_id, REQ, RPC, output_address, sent
    count = 0
    while (True):
        # ret, img = cam.read()

        img = RPC.call(call_type='get', sensor_id='camera001', parameters=[1])
        img = pickle.loads(img)[0]
        img = np.array(img)

        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceDetect.detectMultiScale(gray,
                                                scaleFactor=1.3,
                                                minNeighbors=5
                                                )


        for (x,y,w,h) in faces:
            cv2.imwrite(image_path, gray[y:y+h,x:x+w])
            cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
            cv2.imshow('Security Camera',img);
            cv2.waitKey(30)


            #gets the images one by one
            image_path = image_path

            del_all_flags(tf.flags.FLAGS)

            server_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                                        application_id = app_id, service_id = service_id,
                                        parameters = [10]).decode()

            server_add = server_add.replace("'",'"')
            server_add = json.loads(server_add)
            server_add = server_add['rest_url'].split('/')[0]

            tf.app.flags.DEFINE_string('server', server_add,
                                         'PredictionService host:port')
            tf.app.flags.DEFINE_string('image', image_path, 'path to image in JPEG format')
            FLAGS = tf.app.flags.FLAGS

            host, port = FLAGS.server.split(':')
            channel = implementations.insecure_channel(host, int(port))
            stub = prediction_service_pb2.beta_create_PredictionService_stub(channel)
            # Send request
            with open(FLAGS.image, 'rb') as f:
                # See prediction_service.proto for gRPC request/response details.
                data = f.read()
                request = predict_pb2.PredictRequest()
                request.model_spec.name = 'face_model'
                request.inputs['image'].CopyFrom(
                    tf.contrib.util.make_tensor_proto(data))

                try:
                    result = stub.Predict(request, 10.0)    # 10 secs timeout
                except:
                    print("\033[1;31mFace model address "+server_add+" is not up!\033[0m")

                predictions = result.outputs['prediction'].float_val
                print(predictions)

                prediction = predictions[0]

                if prediction < 0.5:
                    count += 1
                else:
                    count = 0

        print("\n\n\n\n")

        if count > 3:
            emergency_add = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                                        application_id = 'the_third_eye', service_id = 'emergency_notification',
                                        parameters = [10]).decode()

            emergency_add = emergency_add.replace("'",'"')
            emergency_add = json.loads(emergency_add)
            emergency_add = emergency_add['rest_url'].split('/')[0]
            emergency_add = 'http://'+emergency_add

            content_type = 'image/jpeg'
            headers = {'content-type': content_type}
            # encode image as jpeg
            _, img_encoded = cv2.imencode('.jpg', img)
            # send http request with image and receive response

            try:
                if not sent:
                    response = requests.post(emergency_add, data=img_encoded.tostring(), headers=headers)
                    sent = True
            except:
                print("\033[1;31mEmergency notification "+emergency_add+" is not up!\033[0m")

            try:
                response = requests.post(output_address, data=img_encoded.tostring(), headers=headers)
            except:
                print("\033[1;31mOutput address "+output_address+" is not up!\033[0m")


        cv2.imshow('Security Camera',img)
        cv2.waitKey(30)

    # i += 1

if __name__ == '__main__':
    tf.app.run()
    # cam.release()
    cv2.destroyAllWindows()
