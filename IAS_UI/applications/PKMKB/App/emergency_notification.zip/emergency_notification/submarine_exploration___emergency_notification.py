import smtplib, ssl
from RPCHandler import RpcHandler
import pickle
import time
def send_mail(distance):
	# l=['devesh.tewari48@gmail.com']
	# l=["ankush.ngpl23@gmail.com"]
	l=['ankush.ngpl23@gmail.com','devesh.tewari48@gmail.com','varun.g@students.iiit.ac.in','aman.sharma@students.iiit.ac.in','tarpit.sahu@students.iiit.ac.in']
	port = 465  # For SSL
	smtp_server = "smtp.gmail.com"
	for i in l:
		sender_email = "iasproject.2019@gmail.com"  # Enter your address
		receiver_email = i  # Enter receiver address
		password = "#iasproject.2019#"
		message = """\
		Subject: Distance Sensor

		Caution!! The Submarine is about to hit the ground.Distance= """ + str(distance)

		context = ssl.create_default_context()
		with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
		    server.login(sender_email, password)
		    server.sendmail(sender_email, receiver_email, message)
		print("message sent to ",i)

c=0

def f():
	while(1):
		global c

		res= rpc_call.call(call_type= 'get',sensor_id=1,parameters=[1])
		# print("res=",res)
		res=pickle.loads(res)
		# print(type(res))
		distance= res[0]
		# print("distance global = ",distance)
		# print("c= ",c)

		if(distance>=200):
			c=0

		if(distance<200 and c==0):
			print("value <200")
			print("distance= ",distance)
			send_mail(distance)
			c=1

		time.sleep(1)



rpc_call = RpcHandler()
# global c
f()
# c=0
# send_mail(50)
