import requests
import sys
import time
import os
import json
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import xmltodict

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

# service_metadata = database["service_metadata"]
# app_id="submarine_exploration"
# service_id="distance_alarm"
# myquery = { "service_id": service_id, "application_id": app_id }
# mydoc = service_metadata.find(myquery)
#
#
# def find_self_ip():
#     GET_IP_CMD ="hostname -I"
#     def run_cmd(cmd):
#          return subprocess.check_output(cmd, shell=True).decode('utf-8')
#     ip = run_cmd(GET_IP_CMD)
#     ip2=ip.split(" ")
#     return ip2[0]
#
# self_ip=find_self_ip()
#
# for x in mydoc:
# 	node_ips=x['node_ips']
#
# x = node_ips.split(' ')
#
# for m in x:
#     if self_ip in m:
#         port_no=(m.split(':')[1])
#
# print('Assigning following port to flask: ',port_no)


iris_service = 'http://0.0.0.0/8000'

RPC = RpcHandler()
REQ = ReqHandler()

while True:
    # r = requests.get(url = get_url, params = None)
    #
    # data = r.json()

    sonar_data = RPC.call(call_type='get', sensor_id=2, parameters=[1])
    sonar_data = str(sonar_data)

    print('Sonar Data:',sonar_data)

    # r = requests.post(url = post_url, json = sonar_data)
    # res = str(r.json())

    prediction = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                          application_id = 'submarine_exploration', service_id = 'iris_model',
                          parameters = [10])

    print('Prediction:',prediction)
    res = res.replace("'",'"')
    res = json.loads(res)

    r = requests.post(url=iris_service, json=res)

    time.sleep(10)
