from flask import Flask,render_template,request
import time
import json
import os
import pymongo
import xmltodict

app = Flask(__name__)
versicolor_count = 0
setosa_count = 0
virginica_count = 0

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="submarine_exploration"
service_id="distance_alarm"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)


def find_self_ip():
    GET_IP_CMD ="hostname -I"
    def run_cmd(cmd):
         return subprocess.check_output(cmd, shell=True).decode('utf-8')
    ip = run_cmd(GET_IP_CMD)
    ip2=ip.split(" ")
    return ip2[0]

self_ip=find_self_ip()

for x in mydoc:
	node_ips=x['node_ips']

x = node_ips.split(' ')

for m in x:
    if self_ip in m:
        port_no=(m.split(':')[1])

print('Assigning following port to flask: ',port_no)

@app.route("/")
def get_index():
	# return "Count is : " + str(count)
	return render_template('index.html')

@app.route("/status")
def getstatus():
	#iris json
	dict = {}
	dict['setosa'] = setosa_count
	dict['virginica'] = virginica_count
	dict['versicolor'] = versicolor_count
	r = json.dumps(dict)
	return r

@app.route("/update", methods=['GET', 'POST'])
def update():
	#iris json
	data = request.get_json()
	r = data
	val1 = r['results'][0][0][1]
	val2 = r['results'][0][1][1]
	val3 = r['results'][0][2][1]

	maxval = max(val1, val2, val3)
	global versicolor_count
	global setosa_count
	global virginica_count
	if(maxval==val1) :
		versicolor_count += 1
	elif(maxval == val2):
		setosa_count +=1
	else:
		virginica_count+=1

	return '0'


if __name__ == "__main__":
	app.run(host=self_ip, port=port_no)
