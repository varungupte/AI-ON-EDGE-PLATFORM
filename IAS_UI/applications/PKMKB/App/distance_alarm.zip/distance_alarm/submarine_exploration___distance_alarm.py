# TODO
#   take app id and service id from config
#   sensor id






import os
from flask import Flask
import requests
import json
import subprocess
import signal
import sys
import random
import socket
import pymongo
import pickle
import xmltodict

app = Flask(__name__)

cfile_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb= data['platform']['mongodb']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="submarine_exploration"
service_id="distance_alarm"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)


def find_self_ip():
    GET_IP_CMD ="hostname -I"
    def run_cmd(cmd):
         return subprocess.check_output(cmd, shell=True).decode('utf-8')
    ip = run_cmd(GET_IP_CMD)
    ip2=ip.split(" ")
    return ip2[0]

# def free_ports(num_ports):
#     counter = num_ports
#     ports = set()
#     while counter > 0:
#         rport = random.randint(2000,65300)
#         port_binded = False
#         for r in service_port_mapping:
#             if rport == service_port_mapping[r]:
#                 port_binded = True
#                 break
#         if (rport not in ports) and port_binded == False:
#             try:
#                 s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#                 s.bind(("127.0.0.1", rport))
#                 ports.add(str(rport))
#                 counter-=1
#             except socket.error as e:
#                 continue
#             s.close()
#     return ' '.join(list(ports))
#
#
# free_port = str( free_ports(1)[0] )


self_ip=find_self_ip()

for x in mydoc:
	node_ips=x['node_ips']

x = node_ips.split(' ')

for m in x:
    if self_ip in m:
        port_no=(m.split(':')[1])

print('Assigning following port to flask: ',port_no)


RPC = RpcHandler()

@app.route("/")
def get_distance():
    global RPC

    distance = RPC.call(call_type='get', sensor_id=1, parameters=[1])
    distance = pickle.loads(res)
    distance = res[0]

    if distance <= 100:
        status = 'EMERGENCY STOP'
    elif distance > 100 and distance <= 200:
        status = 'CRITICAL'
    else:
        status = 'ALL FINE'

    return status+' '+str(distance)



# proc = subprocess.Popen(['node', './'], env={'PORT': free_port})
#
# def on_signal(sig, frame):
#     print('Signal handler called with signal', sig)
#     proc.kill()
#     sys.exit(0)
#
# signal.signal(signal.SIGTERM, on_signal)


if __name__ == "__main__":
	app.secret_key = os.urandom(12)
	app.run(debug=True, host=self_ip, port=int(port_no))
