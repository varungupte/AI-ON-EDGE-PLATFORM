import requests
import sys
import time
import os
import json
import pymongo
from RPCHandler import RpcHandler
from REQHandler import ReqHandler
import xmltodict
import pickle


# get_url = "http://"+str(sys.argv[1])
# post_url = "http://"+str(sys.argv[2])+"/v1/models/cool:classify"
counter_service = "http://0.0.0.0:8010"

while True:
    # r = requests.get(url = get_url, params = None)
    #
    # data = r.json()

    sonar_data = RPC.call(call_type='get', sensor_id=2, parameters=[1])
    sonar_data = pickle.load(sonar_data)

    print(sonar_data)

    # r = requests.post(url = post_url, json = data)
    # res = str(r.json())
    prediction = REQ.call(call_type = 'rest_call', call_to = 'server/edge',
                          application_id = 'submarine_exploration', service_id = 'sonar_model',
                          parameters = [10])
    prediction = res.replace("'",'"')
    prediction = json.loads(prediction)

    var_0 = (prediction['results'][0][0][1])
    var_1 = (prediction['results'][0][1][1])

    if(var_1 > var_0):
        requests.get(url=counter_service, params=None)


    time.sleep(10)
