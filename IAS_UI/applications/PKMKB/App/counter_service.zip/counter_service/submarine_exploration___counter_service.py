from flask import Flask,render_template
import time
import json
import os
import pymongo

app = Flask(__name__)

import xmltodict

file_name = os.path.expanduser("~/nfs/platform/platform_configs/platform_config.xml")
config_file=open(file_name,"r")
data=config_file.read()
config_file.close()
data=xmltodict.parse(data)
runner_ip=data['platform']['rabbit_server_ip']
mongodb=data['platform']['mongodb']
deploy_manager_ip=data['platform']['deploy_manager_ip']
myclient = pymongo.MongoClient(mongodb)

database = myclient["metadata"]

service_metadata = database["service_metadata"]
app_id="submarine_exploration"
service_id="counter_service"
myquery = { "service_id": service_id, "application_id": app_id }
mydoc = service_metadata.find(myquery)


def find_self_ip():
    GET_IP_CMD ="hostname -I"
    def run_cmd(cmd):
         return subprocess.check_output(cmd, shell=True).decode('utf-8')
    ip = run_cmd(GET_IP_CMD)
    ip2=ip.split(" ")
    return ip2[0]

self_ip=find_self_ip()

for x in mydoc:
	node_ips=x['node_ips']

x = node_ips.split(' ')

for m in x:
    if self_ip in m:
        port_no=(m.split(':')[1])

print('Assigning following port to flask: ',port_no)

count = 0
count = int((open("demofile.txt", "r")).read())
#print(count)

@app.route("/")
def get_index():
	global count
	#count = count + 1
	# return "Count is : " + str(count)
	return render_template('test.html', counter = count)

@app.route("/inc")
def inc():
	global count
	count = count + 1
	return str(count)


def inc30():
    while(True):
        global count
        time.sleep(30)
        count+=1
    return

if __name__ == "__main__":
	t1 = threading.Thread(target=inc30, args=())
    t1.start()
	app.run(host=self_ip, port=port_no)
